﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Snt.PrintLibrary.Zebra
{
    public class Label
    {
        public string Id;
        public string Text;
        public int XPos;
        public int YPos;
    }
}
