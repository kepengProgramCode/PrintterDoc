﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;
using System.Data;

namespace Snt.PrintLibrary.Zebra
{
    using System = global::System;
    using ThoughtWorks.QRCode.Codec;
    using System.Drawing;
    using System.Drawing.Printing;
    public class Printer
    {
        private string name;
        /// <summary>
        /// 打印机型号
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        #region 获取打印机名称，如
        public Printer()
        {
            this.Name = System.Configuration.ConfigurationManager.AppSettings["Printer"];
        }
        public Printer(string name)
        {
            this.Name = name;
        }
        #endregion

        #region DLL声明
        //ZPL
        [DllImport(@"FNTHEX32.DLL", CharSet = CharSet.Ansi)]
        public static extern int GETFONTHEX(
                          string chnstr,
                          string fontname,
                          string chnname,
                          int orient,
                          int height,
                          int width,
                          int bold,
                          int italic,
                          StringBuilder param1);
        //EPL
        [DllImport(@"Eltronp.dll", CharSet = CharSet.Ansi)]
        public static extern int PrintHZ(int Lpt, //0：LPT1，1 LPT2
                                         int x,
                                         int y,
                                         string HZBuf,
                                         string FontName,
                                         int FontSize,
                                         int FontStyle);
        #endregion

        #region 指令说明
        /**
        ^XA 开始 ^XZ 结束
        ^LH起始坐标  ^PR进纸回纸速度 ^MD 对比度
        ^FO标签左上角坐标  ^XG打印图片参数1图片名称后两个为坐标
        ^FS标签结束符  ^CI切换国际字体 ^FT坐标 ^FD定义一个字符串
        ^A定义字体  ^FH十六进制数 ^BY模块化label ^BC条形码128  
        ^PQ打印设置 参数一 打印数量 参数二暂停 参数三重复数量  参数四为Y时表明无暂停
         **/
        #endregion

        #region PrintDocument 打印条码、二维码
        public void Print()
        {
            System.Drawing.Printing.PrintDocument _Document = new System.Drawing.Printing.PrintDocument();
            _Document.PrintPage += _Document_PrintPage;
            PageSettings pageSet = new PageSettings();
            pageSet.Landscape = false;
            pageSet.Margins.Top = 0;
            pageSet.Margins.Left = 1;
            pageSet.PaperSize = new System.Drawing.Printing.PaperSize("小票", 2, 2);
            _Document.DefaultPageSettings = pageSet;
            _Document.Print();
        }
        void _Document_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            float x = 0;
            float y = 0;
            float width = 300;
            float height = 60;
            // 在此处调用CreateBarcodeImage方法，注意指定保存路径
            e.Graphics.DrawImage(CreateBarcodeImage("test", "test.png"), x, y, width, height);
            e.HasMorePages = false;
        }
        #endregion

        #region ZPL 打印条码、二维码
        /// <summary>
        /// 条码打印(标签两列)
        /// </summary>
        /// <param name="l">左边距 推荐值：0</param>
        /// <param name="h">上边距 推荐值：0</param>
        /// <param name="cl">第一列与第二列的距离 推荐值：0</param>
        /// <param name="bch">条码高 推荐值：0</param>
        /// <param name="str">条码内容1，内容2两个字符串 推荐值：11位字母数字组成</param>
        /// <returns>true /false 执行状态</returns>
        public bool PrintBarcode(int l, int h, int cl, int bch, params string[] str)
        {
            l = l == 0 ? 55 : l;
            h = h == 0 ? 55 : h;
            cl = cl == 0 ? 10 : cl;
            bch = bch == 0 ? 70 : bch;
            StringBuilder sb = new StringBuilder();
            sb.Append("^XA");
            //连续打印两列（单列只写一条）
            sb.Append(string.Format("^MD30^LH{0},{1}^FO{2},{3}^ACN,18,5^BY1,3,{4}^BC,Y,N^FD{5}^FS", l, h, l, h, bch, str[0]));
            // sb.Append(string.Format("^MD30^LH{0},{1}^FO{2},{3}^ACN,18,10^BY1.8,3,{4}^BC,,Y,N^FD{5}^FS", l, h, l + cl, h, bch, str[1]));

            sb.Append("^XZ");
            return RawPrinterHelper.SendStringToPrinter(this.name, sb.ToString());
        }
        public string PictureToZPL(string s_FilePath)
        {
            int b = 0;
            long n = 0;
            long clr;
            StringBuilder stringBuilder = new StringBuilder();
            //====================================================================================//
            stringBuilder.Append("~DGR:ZONE.GRF,");
            Bitmap bm = new Bitmap(s_FilePath);
            int w = ((bm.Size.Width / 8 + ((bm.Size.Width % 8 == 0) ? 0 : 1)) * bm.Size.Height);
            int h = (bm.Size.Width / 8 + ((bm.Size.Width % 8 == 0) ? 0 : 1));

            stringBuilder.Append(w.ToString().PadLeft(5, '0') + "," + h.ToString().PadLeft(3, '0') + ",\n");
            using (Bitmap bmp = new Bitmap(bm.Size.Width, bm.Size.Height))
            {
                for (int y = 0; y < bm.Size.Height; y++)
                {
                    for (int x = 0; x < bm.Size.Width; x++)
                    {
                        b = b * 2;
                        clr = bm.GetPixel(x, y).ToArgb();
                        string s = clr.ToString("X");

                        if (s.Substring(s.Length - 6, 6).CompareTo("BBBBBB") < 0)
                        {
                            bmp.SetPixel(x, y, bm.GetPixel(x, y));
                            b++;
                        }
                        n++;
                        if (x == (bm.Size.Width - 1))
                        {
                            if (n < 8)
                            {
                                b = b * (2 ^ (8 - (int)n));

                                stringBuilder.Append(b.ToString("X").PadLeft(2, '0'));
                                b = 0;
                                n = 0;
                            }
                        }
                        if (n >= 8)
                        {
                            stringBuilder.Append(b.ToString("X").PadLeft(2, '0'));
                            b = 0;
                            n = 0;
                        }
                    }
                }
                stringBuilder.Append("^XGZONE.GRF");

            }
            return stringBuilder.ToString();
        }
        /// <summary>
        /// 二维码打印(标签两列)
        /// </summary>
        /// <param name="left">左边距 推荐值：0</param>
        /// <param name="height">上边距 推荐值：0</param>
        /// <param name="cl">第一列与第二列的距离 推荐值：0</param>
        /// <param name="barcodeHeight">二维码放大倍数 推荐值：0</param>
        /// <param name="str">内容1，内容2两个字符串 推荐值：字母数字组成（位数不限制）</param>
        /// <returns>true /false 执行状态</returns>
        public bool PrintQRCode(int left, int height, params string[] str)
        {
            string str0 = str[0];
            left = (left == 0 ? 480 : left);
            height = (height == 0 ? 10 : height);
            int printX = 0;
            int printY = 0;
            StringBuilder stringBuilder = new StringBuilder();
            // ^XA:开始标签格式
            stringBuilder.Append("^XA");
            //^MD（标签深度）指令调整与当前设定深度的关系，最小值 -30，最大30
            stringBuilder.AppendFormat("^MD{0}", 30);
            //====================================================================================//
            //^AD:点阵字体尺寸
            stringBuilder.AppendFormat("^AD,{0}", 20);
            // ^LH命令指定的标签原点
            stringBuilder.AppendFormat("^LH{0},{1}", 460, 65);
            // ＾FO命令设置字段的左上角的位置
            stringBuilder.AppendFormat("^FO{0},{1}", 0, 0);
            stringBuilder.AppendFormat(@"~DGhead,00780,026,jT02S038M06H0CL0EO0EH0EK038H07O03N0380FL0EO0CH0EK07I06O03N03H0
                  C02I01CM040CH0CK0E010C03M03N03H0C07I018M038CH0CK0IFDIF8L03K01NFCH03KF8H01HCH0C06
                  H018403H8K03H03H038J03H0CK07J03I018DKF803030306K03LF8J03H0CK0EJ03K0CH0CJ06038403
                  K03803H03K03H0CJ01CJ03J01CH0CJ0C230803K03803H03K02H08J018H0203J0ECH0CI010381N038
                  03H03L06L037IF03I070CH0CK03H08H0EJ03803H03L038K046H0603H03E0CH0C1CI0308IFEJ03LFJ
                  0181CK086H0603H0180C7JFI0H3HCH0EJ03803H03K0E0EJ0306H0603K0C6K01HFC0CH0EJ03803H03
                  I010C0602J06H0603K0C38L07H0CH0EJ03803H03I010C06018I06H0603L01CH06I07H0IFEJ03803H
                  03I030CJ0EI07IF07H017HF8HFEF8H0FE0CH0EJ03803H03I030CJ07I06H0707I08H07801J0F38CH0
                  EJ03LFI070CI0438H06J06K01C4038H01B1HCH0EJ03803H03I0F0CI0438H06I0FE1J0302078H0H30
                  8CH0EJ03803K01E0CI0418H06I01C1J0E030CI063H0IFEJ02H03I01H080CI04J06I0101I03E01FJ0
                  43H0CH0EM03I01J0CI04J06K01H01C6H06J083H0CH0EM03I03J0EI0FJ06K03H06060H38H0103H0CH
                  0EM03I038I0JFEJ07K03838063C1FJ03H0CH0EM038H03CR03LF8I07EH07FCH03H0IFEM01JFT07JFE
                  J07J0FI03H0CH0EgV02J02I02H08H08hU0");
            stringBuilder.Append("^XGhead");
            stringBuilder.Append("^FS");
            //====================================================================================//
            //****logo
            //====================================================================================//
            //^AD:点阵字体尺寸
            stringBuilder.AppendFormat("^AD,{0}", 10);
            // ^LH命令指定的标签原点
            stringBuilder.AppendFormat("^LH{0},{1}", 660, 10);
            // ＾FO命令设置字段的左上角的位置
            stringBuilder.AppendFormat("^FO{0},{1}", 0, 0);
            stringBuilder.Append(PictureToZPL("d:\\microvast.bmp"));
            stringBuilder.Append("^FS");
            //====================================================================================//
            //***
            //^AD:点阵字体尺寸
            stringBuilder.AppendFormat("^AD,{0}", 20);
            // ^LH命令指定的标签原点
            stringBuilder.AppendFormat("^LH{0},{1}", 300, 150);
            // ＾FO命令设置字段的左上角的位置
            stringBuilder.AppendFormat("^FO{0},{1}", 0, 0);
            stringBuilder.AppendFormat(@"~DGgrade,00480,016,gX04gM07I07K02gG07I0EK078g0E030C01I060JFCT01IF9IF8H0CH0603CT0
                              1H80108I01CH0603U030C0206I018H0607U06060407I03038606U08061C07I0607060CT01H060CK0
                              C060E1CY0C018018FC0E186U0LFE01F180E3HFX0CL03H0E10EX0CH01I06H0EH0CX0CH038H0CH0DH0
                              CH018O01JF3HFCH018H0D018H07EU018I03H01H818H07EU01CI0C3E18C3I07CU018701FC01847U07
                              LFH80CH030H6W04H018L0303CW03H018K076018I018R038018J078C07EI07CR01C018I0FC180E7I0
                              7ER018018H01E030383CH03CT07F8I080C0EH0FCX0F8J0103I06Y06M0ChO0");
            stringBuilder.Append("^XGgrade");
            stringBuilder.Append("^FS");
            //=================================================================================//
            //^AD:点阵字体尺寸
            stringBuilder.AppendFormat("^AD,{0}", 30);
            // ^LH命令指定的标签原点
            stringBuilder.AppendFormat("^LH{0},{1}", 350, 200);
            // ＾FO命令设置字段的左上角的位置
            stringBuilder.AppendFormat("^FO{0},{1}", 0, 0);
            stringBuilder.AppendFormat("^FD{0}", "A");
            stringBuilder.Append("^FS");
            //=================================================================================//
            //^AD:点阵字体尺寸
            stringBuilder.AppendFormat("^AD,{0}", 20);
            // ^LH命令指定的标签原点
            stringBuilder.AppendFormat("^LH{0},{1}", 400, 150);
            // ＾FO命令设置字段的左上角的位置
            stringBuilder.AppendFormat("^FO{0},{1}", 0, 0);
            // ^BCN,100,Y,N,N打印不旋转的高度为100点的Code128条码
            stringBuilder.Append("^BY2,3^BCN,150,Y,N,N");
            // 需要打印的内容
            stringBuilder.AppendFormat("^FD{0}", str0);
            // 字段定义结束
            stringBuilder.Append("^FS");
            //================================================================================//
            // ^XZ结束标签格式
            stringBuilder.Append("^XZ");
            // 二维码指令 BQ
            //sb.Append(string.Format("^MD30^LH{0},{1}^FO{2},{3}^BQ,2,{4}^FDQA,{5}^FS", left, height, 100, height, bch, str0[0]));
            // 列印数字(二维码使用)
            //sb.Append(string.Format("^FT{0},{1}^XG{2},1,1^FS", 125 + cl, height + 90, str0[0]));
            // 一维码指令 ^BY3^BCN           字体参数

            Console.WriteLine(stringBuilder.ToString());
            return RawPrinterHelper.SendStringToPrinter(this.name, stringBuilder.ToString());

            //sb.Append(TextToHex(str0[1], str0[0], 24));

            //sb.Append(string.Format("^FT{0},{1}^XG{2},1,1^FS", 125 + cl, height + 60, str0[0]));
            // sb.Append(TextToHex(str0[0], str0[0], 20));

            //string a = "^XA	^JMA	^LH10,0	^FO400,10	^BY1,2.0,55	^PRC,D,D	^A0,I,30,200	^BC1,System.Windows.Forms.TextBox, Text: 55,N,N	^FDDJ1603-17C05-1738-013^FS	^XZ";
            //return RawPrinterHelper.SendStringToPrinter(this.Name, a);

        }
        /// <summary>
        /// 二维码打印(标签两列)
        /// </summary>
        /// <param name="left">左边距 推荐值：0</param>
        /// <param name="height">上边距 推荐值：0</param>
        /// <param name="cl">第一列与第二列的距离 推荐值：0</param>
        /// <param name="bch">二维码放大倍数 推荐值：0</param>
        /// <param name="Barcode">：字母数字组成（位数不限制）</param>
        /// <returns>true /false 执行状态</returns>
        public bool PrintBarcode(int left, int height, int cl, int bch, string barcode)
        {
            left = (left == 0 ? 40 : left);
            height = (height == 0 ? 5 : height);
            cl = (cl == 0 ? 2 : cl);
            bch = (bch == 0 ? 5 : bch);

            StringBuilder sb = new StringBuilder();
            sb.Append("^XA");

            sb.Append(string.Format("^RH{0},{1}^FO{2},{3}^BQ,2,{4}^FDQA,{5}^FS", left, height, 0, height, bch, barcode));
            sb.Append(TextToHex(barcode, barcode, 24));

            sb.Append(string.Format("^FT{0},{1}^XG{2},1,1^FS", cl, height, barcode));

            //sb.Append(string.Format("^LH{0},{1}^FO{2},{3}^BQ,2,{4}^FDQA,{5}^FS", left, height, 0 + cl, height, bch, str1[0]));
            //sb.Append(TextToHex(str1[1], str1[0], 24));
            //sb.Append(string.Format("^FT{0},{1}^XG{2},1,1^FS", 125 + cl + left, height + 60, str1[0]));
            //sb.Append(TextToHex(str1[0], str1[0], 20));
            //sb.Append(string.Format("^FT{0},{1}^XG{2},1,1^FS", 125 + cl + left, height + 90, str1[0]));
            sb.Append("^XZ");
            return RawPrinterHelper.SendStringToPrinter(this.Name, sb.ToString());
        }

        #endregion

        #region 条码、二维码图片生成
        /// <summary>
        /// 生成条形码图片
        /// </summary>
        /// <param name="num">条形码序列号</param>
        /// <param name="path">图片存放路径（绝对路径）</param>
        /// <returns>返回图片</returns>
        public System.Drawing.Image CreateBarcodeImage(string num, string path)
        {

            BarcodeLib.Barcode barcode = new BarcodeLib.Barcode();
            barcode.BackColor = System.Drawing.Color.White;
            barcode.ForeColor = System.Drawing.Color.Black;
            barcode.IncludeLabel = true;
            barcode.Alignment = BarcodeLib.AlignmentPositions.CENTER;
            barcode.LabelPosition = BarcodeLib.LabelPositions.BOTTOMCENTER;
            barcode.ImageFormat = System.Drawing.Imaging.ImageFormat.Png;
            System.Drawing.Font font = new System.Drawing.Font("verdana", 10f);
            barcode.LabelFont = font;
            try
            {
                System.Drawing.Image image = barcode.Encode(BarcodeLib.TYPE.CODE128B, num);
                image.Save(path);
                return image;
            }
            catch (Exception)
            {

            }
            return null;
        }
        /// <summary>
        /// 生成二维码图片
        /// </summary>
        /// <param name="num">二维码序列号</param>
        /// <param name="path">图片存放路径（绝对路径）</param>
        /// <returns>返回图片</returns>
        public System.Drawing.Image CreateQRCodeImage(string num, string path)
        {
            QRCodeEncoder qrCodeEncoder = new QRCodeEncoder();
            String encoding = "Byte";
            if (encoding == "Byte")
            {
                qrCodeEncoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.BYTE;
            }
            else if (encoding == "AlphaNumeric")
            {
                qrCodeEncoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.ALPHA_NUMERIC;
            }
            else if (encoding == "Numeric")
            {
                qrCodeEncoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.NUMERIC;
            }
            try
            {
                int scale = Convert.ToInt16(4);
                qrCodeEncoder.QRCodeScale = scale;
            }
            catch (Exception)
            {

            }
            try
            {
                int version = Convert.ToInt16(7);
                qrCodeEncoder.QRCodeVersion = version;
            }
            catch (Exception)
            {

            }

            string errorCorrect = "M";
            if (errorCorrect == "L")
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.L;
            else if (errorCorrect == "M")
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M;
            else if (errorCorrect == "Q")
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.Q;
            else if (errorCorrect == "H")
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.H;
            try
            {
                Bitmap bm = qrCodeEncoder.Encode(num);
                bm.Save(path);
                MemoryStream ms = new MemoryStream();
                bm.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return System.Drawing.Image.FromStream(ms);
            }
            catch (Exception)
            {

            }
            return null;
        }
        #endregion

        #region ZPL 打印中文小票
        public string TextToHex(string text, string textId, int height)
        {
            StringBuilder hexBuilder = new StringBuilder(4 * 1024);
            int subStrCount = 0;
            subStrCount = GETFONTHEX(text, "Arial", textId, 0, height, 0, 1, 0, hexBuilder);
            return hexBuilder.ToString().Substring(0, subStrCount);
        }
        public string DeviceLabelToHex(string text, string textId)
        {
            StringBuilder hexBuilder = new StringBuilder(4 * 1024);
            int subStrCount = 0;
            subStrCount = GETFONTHEX(text, "Arial", textId, 0, 40, 0, 1, 0, hexBuilder);
            return hexBuilder.ToString().Substring(0, subStrCount);
        }
        public bool IsZebraPrinter(string printerName)
        {
            return printerName.IndexOf("ZDesigner") + printerName.IndexOf("Zebra") >= -1;
        }
        public void ZPLPrintDeviceLabel(DataTable dt, int copies)
        {
            ZPLPrintDeviceLabel(dt, true, copies);
        }
        public void ZPLPrintDeviceLabel(DataTable dt, bool isRequireTextToHex, int copies)
        {
            Snt.PrintLibrary.Zebra.Label label = null;
            for (int i = 0; i < copies; i++)
            {
                foreach (DataRow row in dt.Rows)
                {
                    List<Snt.PrintLibrary.Zebra.Label> labelList = new List<Snt.PrintLibrary.Zebra.Label>();
                    label = new Snt.PrintLibrary.Zebra.Label();
                    #region Data
                    label.Id = "HName";
                    label.Text = row["HName"].ToString();
                    label.XPos = 150;
                    label.YPos = 60;
                    labelList.Add(label);

                    label = new Snt.PrintLibrary.Zebra.Label();
                    label.Id = "AName";
                    label.Text = row["AName"].ToString();
                    label.XPos = 10;
                    label.YPos = 140;
                    labelList.Add(label);

                    //label = new Project.Printers.Prints.Label();
                    //label.Id = "name1";
                    //label.Text = row["name1"].ToString();
                    //label.XPos = 70;
                    //label.YPos = 180;
                    //labelList.Add(label);

                    label = new Snt.PrintLibrary.Zebra.Label();
                    label.Id = "ANo";
                    label.Text = row["ANo"].ToString();
                    label.XPos = 10;
                    label.YPos = 185;
                    labelList.Add(label);

                    //label = new Project.Printers.Prints.Label();
                    //label.Id = "No1";
                    //label.Text = row["No1"].ToString();
                    //label.XPos = 70;
                    //label.YPos = 245;
                    //labelList.Add(label);

                    label = new Snt.PrintLibrary.Zebra.Label();
                    label.Id = "UResponsible";
                    label.Text = row["UResponsible"].ToString();
                    label.XPos = 10;
                    label.YPos = 234;
                    labelList.Add(label);

                    //label = new Project.Printers.Prints.Label();
                    //label.Id = "Responsible1";
                    //label.Text = row["Responsible1"].ToString();
                    //label.XPos = 70;
                    //label.YPos = 305;
                    //labelList.Add(label);

                    label = new Snt.PrintLibrary.Zebra.Label();
                    label.Id = "RPerson";
                    label.Text = row["RPerson"].ToString();
                    label.XPos = 325;
                    label.YPos = 140;
                    labelList.Add(label);

                    //label = new Project.Printers.Prints.Label();
                    //label.Id = "Person1";
                    //label.Text = row["Person1"].ToString();
                    //label.XPos = 355;
                    //label.YPos = 180;
                    //labelList.Add(label);

                    label = new Snt.PrintLibrary.Zebra.Label();
                    label.Id = "BDate";
                    label.Text = row["BDate"].ToString();
                    label.XPos = 10;
                    label.YPos = 334;

                    labelList.Add(label); label = new Snt.PrintLibrary.Zebra.Label();
                    label.Id = "UPrice";
                    label.Text = row["UPrice"].ToString();
                    label.XPos = 325;
                    label.YPos = 185;
                    labelList.Add(label);

                    labelList.Add(label); label = new Snt.PrintLibrary.Zebra.Label();
                    label.Id = "MResponsible";
                    label.Text = row["MResponsible"].ToString();
                    label.XPos = 10;
                    label.YPos = 280;
                    #endregion
                    labelList.Add(label);

                    if (isRequireTextToHex)
                    {
                        ZPLPrintLabels(this.name, labelList.ToArray(), 100);
                    }
                    else
                    {
                        ZPLPrintLabelsWithHexText(this.name, labelList.ToArray());
                    }
                }
            }
        }
        private void ZPLPrintLabelsWithHexText(string printerName, Snt.PrintLibrary.Zebra.Label[] labels)
        {
            string labelIdCmd = string.Empty;
            string labelContentCmd = string.Empty;
            foreach (Snt.PrintLibrary.Zebra.Label label in labels)
            {
                labelIdCmd += "^FT" + label.XPos.ToString() + "," + label.YPos.ToString() + "^XG" + label.Id + ",1,1^FS";
                labelContentCmd += label.Text;
            }
            string content = labelContentCmd
                + "^XA^LH0,0^PR2,2^MD20^FO0,0"
                + labelIdCmd
                + "^PQ1,0,1,Y^XZ";
            RawPrinterHelper.SendStringToPrinter(printerName, content);
        }
        private void ZPLPrintLabels(string printerName, Snt.PrintLibrary.Zebra.Label[] labels, int height)
        {
            string labelIdCmd = string.Empty;
            string labelContentCmd = string.Empty;
            string headTitle = string.Empty;
            string barcodeNo = string.Empty;
            foreach (Snt.PrintLibrary.Zebra.Label label in labels)
            {
                labelIdCmd += "^FT" + label.XPos.ToString() + "," + label.YPos.ToString() + "^XG" + label.Id + ",1,1^FS";
                if (label.Id == "HName")
                {
                    //headTitle += "^FDMA," + label.Id + "^FS";
                }
                if (label.Id == "ANo")
                {
                    barcodeNo += "^FDMA,YF10069^FS";
                }
                labelContentCmd += TextToHex(label.Text, label.Id, height);
            }
            #region 打印具有格式的小票
            string content = labelContentCmd
                + "^XA^LH0,0^PR2,2^MD20^FO0,0"
                //+ headTitle
                + "^FO20,80^GB560,0,3^FS"
                + labelIdCmd
                + "^FT455,340^BQN,2,4"
                + barcodeNo
                + "^PQ1,0,1,Y^XZ";
            RawPrinterHelper.SendStringToPrinter(printerName, content);
            #endregion
        }
        #endregion


    }
}
