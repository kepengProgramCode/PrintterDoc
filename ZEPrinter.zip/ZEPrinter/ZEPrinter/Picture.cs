﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZEPrinter
{
    public class Picture
    {
        private string filePath;

        public string FilePath
        {
            get { return filePath; }
            set { filePath = value; }
        }
        public string ConvertPictureToHex()
        {
            FileStream fs = new FileStream(this.filePath, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            StringBuilder sb = new StringBuilder();
            int length = (int)fs.Length;
            while (length > 0)
            {
                byte bt = br.ReadByte();
                string tempStr = Convert.ToString(bt, 16);
                sb.Append(tempStr);
                length--;
            }
            return sb.ToString();
        }
        public string ConvertPictureToZPL(string s_FilePath)
        {
            int b = 0;
            long n = 0;
            long clr;
            StringBuilder stringBuilder = new StringBuilder();

            // ^XA:开始标签格式
            stringBuilder.Append("^XA");
            //^MD（标签深度）指令调整与当前设定深度的关系，最小值 -30，最大30
            stringBuilder.AppendFormat("^MD{0}", 30);
            //====================================================================================//
            //^AD:点阵字体尺寸
            stringBuilder.AppendFormat("^AD,{0}", 5);
            // ^LH命令指定的标签原点
            stringBuilder.AppendFormat("^LH{0},{1}", 300, 50);
            // ＾FO命令设置字段的左上角的位置
            stringBuilder.AppendFormat("^FO{0},{1}", 0, 0);

            stringBuilder.Append("~DGR:ZONE.GRF,");
            Bitmap bm = new Bitmap(s_FilePath);
            int w = ((bm.Size.Width / 8 + ((bm.Size.Width % 8 == 0) ? 0 : 1)) * bm.Size.Height);
            int h = (bm.Size.Width / 8 + ((bm.Size.Width % 8 == 0) ? 0 : 1));

            stringBuilder.Append(w.ToString().PadLeft(5, '0') + "," + h.ToString().PadLeft(3, '0') + ",\n");
            using (Bitmap bmp = new Bitmap(bm.Size.Width, bm.Size.Height))
            {
                for (int y = 0; y < bm.Size.Height; y++)
                {
                    for (int x = 0; x < bm.Size.Width; x++)
                    {
                        b = b * 2;
                        clr = bm.GetPixel(x, y).ToArgb();
                        string s = clr.ToString("X");

                        if (s.Substring(s.Length - 6, 6).CompareTo("BBBBBB") < 0)
                        {
                            bmp.SetPixel(x, y, bm.GetPixel(x, y));
                            b++;
                        }
                        n++;
                        if (x == (bm.Size.Width - 1))
                        {
                            if (n < 8)
                            {
                                b = b * (2 ^ (8 - (int)n));

                                stringBuilder.Append(b.ToString("X").PadLeft(2, '0'));
                                b = 0;
                                n = 0;
                            }
                        }
                        if (n >= 8)
                        {
                            stringBuilder.Append(b.ToString("X").PadLeft(2, '0'));
                            b = 0;
                            n = 0;
                        }
                    }
                }
                stringBuilder.Append("^XGZONE.GRF");
                stringBuilder.Append("^FS");
                // ^XZ结束标签格式
                stringBuilder.Append("^XZ");
            }
            return stringBuilder.ToString();
        }
    }
}
