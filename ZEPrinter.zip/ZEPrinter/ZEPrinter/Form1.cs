﻿using Snt.PrintLibrary.Zebra;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZEPrinter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            Snt.PrintLibrary.Zebra.Printer printer = new Snt.PrintLibrary.Zebra.Printer("ZDesigner ZE500-4 RH-203dpi ZPL");
            printer.PrintQRCode(0, 0, textBoxContent.Text);
        }

        private void buttonPrintPic_Click(object sender, EventArgs e)
        {
            Picture p = new Picture();
            p.FilePath = "d:\\microvast.bmp";
            RawPrinterHelper.SendStringToPrinter("ZDesigner ZE500-4 RH-203dpi ZPL", p.ConvertPictureToZPL(p.FilePath));
        }
    }
}
